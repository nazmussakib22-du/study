// content.js

// 1. Bridge messages from instrument.js (MAIN world) to background.js
window.addEventListener("message", (event) => {
    // Only accept messages from our own window
    if (event.source !== window) return;

    if (event.data && event.data.type === "LOG_CRAWL_F9743") {
        chrome.runtime.sendMessage(event.data);
    }
});

// 2. Anti-Bot Detection Logic (Ported from challenge_logger.py)
const ANTI_BOT_SELECTORS = {
    "cf_turnstile": '#cf-turnstile, .cf-browser-verification, #challenge-running, [data-translate="challenge_headline"]',
    "datadome": "#datadome-captcha",
    "perimeterx": "#px-captcha",
    "akamai": "script[src*='akamai-bm-telemetry'], [src*='akamai-bm-telemetry']",
    "incapsula": "iframe[src*='incapsula']",
    "recaptcha": "iframe[src*='google.com/recaptcha']",
    "hcaptcha": "iframe[src*='hcaptcha.com']",
    "cf_challenge_iframe": "iframe[src*='challenges.cloudflare.com']",
    "awswaf": "script[src*='awswaf.com']",
    "geetest": ".geetest_captcha"
};

const PROVIDER_FAMILIES = {
    cloudflare: ["cf_turnstile", "cf_challenge_iframe"],
    datadome: ["datadome"], 
    perimeterx: ["perimeterx"],
    akamai: ["akamai"],
    incapsula: ["incapsula"],
    generic_captcha: ["recaptcha", "hcaptcha", "awswaf", "geetest"]
};

let lastReportedState = "";

function isElementHidden(el) {
  const rect = el.getBoundingClientRect();
  
  // 1. Dimensional check (handles display:none on self or ancestors)
  if (rect.width <= 10 || rect.height <= 10) return true;
  
  // 2. Viewport intersection check (catches off-screen positioning)
  if (
    rect.bottom <= 0 ||
    rect.right <= 0 ||
    rect.top >= (window.innerHeight || document.documentElement.clientHeight) ||
    rect.left >= (window.innerWidth || document.documentElement.clientWidth)
  ) {
    return true;
  }

  // 3. Recursive CSS visibility/opacity check (catches hidden parent wrappers)
  let currentEl = el;
  while (currentEl) {
      const style = window.getComputedStyle(currentEl);
      const opacity = Number.parseFloat(style.opacity || "1");
      
      if (style.visibility === "hidden" || style.display === "none" || opacity === 0) {
          return true;
      }
      currentEl = currentEl.parentElement;
  }

  return false;
}

function detectAntiBot() {
  try {
    const hits = [];
    const domFlags = { datadome: false, perimeterx: false, incapsula: false };

    for (const [key, selector] of Object.entries(ANTI_BOT_SELECTORS)) {
      if (document.querySelector(selector)) hits.push(key);
    }

    if (document.querySelector("script[src*='captcha-delivery.com'], iframe[src*='captcha-delivery.com'], script[src*='geo.captcha-delivery.com'], iframe[src*='geo.captcha-delivery.com']")) {
      domFlags.datadome = true;
    }
    if (document.querySelector("script[src*='perimeterx'], script[src*='client.perimeterx.net'], iframe[src*='perimeterx'], iframe[src*='client.perimeterx.net']")) {
      domFlags.perimeterx = true;
    }
    if (document.querySelector("script[src*='incapsula'], iframe[src*='incapsula']")) {
      domFlags.incapsula = true;
    }

    if (hits.length === 0 && !domFlags.datadome && !domFlags.perimeterx && !domFlags.incapsula) return;

    let blockFamily = null;
    if (hits.some(h => PROVIDER_FAMILIES.cloudflare.includes(h))) blockFamily = "cloudflare";
    else if (domFlags.datadome || hits.includes("datadome")) blockFamily = "datadome";
    else if (domFlags.perimeterx || hits.includes("perimeterx")) blockFamily = "perimeterx";
    else if (hits.includes("akamai")) blockFamily = "akamai";
    else if (domFlags.incapsula || hits.includes("incapsula")) blockFamily = "incapsula";
    else if (hits.some(h => PROVIDER_FAMILIES.generic_captcha.includes(h))) blockFamily = "generic_captcha";

    // Standardized visibility evaluation for ALL block families
    let isHidden = false;
    let hasAny = false;
    let allHidden = true;

    const familyKeys = blockFamily ? PROVIDER_FAMILIES[blockFamily] : [];
    if (familyKeys) {
      for (const key of familyKeys) {
        if (!ANTI_BOT_SELECTORS[key]) continue;
        
        const nodes = document.querySelectorAll(ANTI_BOT_SELECTORS[key]);
        for (const el of nodes) {
          hasAny = true;
          if (!isElementHidden(el)) {
            allHidden = false;
            break; 
          }
        }
        if (hasAny && !allHidden) break; 
      }
    }

    // Logic: If physical elements exist, visibility depends on their render state.
    // If no physical elements exist (script-only detection), it is inherently hidden.
    if (hasAny) {
        isHidden = allHidden;
    } else {
        isHidden = true; 
    }

    const stateHash = `${hits.sort().join(",")}|${JSON.stringify(domFlags)}|${isHidden}`;
    if (stateHash !== lastReportedState) {
      lastReportedState = stateHash;
      chrome.runtime.sendMessage({
        type: "DOM_BLOCK_DETECTED",
        payload: {
          url: window.location.href,
          hits: hits,
          domFlags: domFlags,
          hidden: isHidden,
          title: document.title,
          timestamp: Date.now()
        }
      });
    }
  } catch (_) {}
}

// 3. Execution Strategy: Initial check + MutationObserver for dynamic injects
let debounceTimer = null;
const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(detectAntiBot, 500);
});

// Start observing immediately
observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style', 'class'] // Catch CAPTCHAs toggling visibility
});

// Run an initial check in case elements are already present
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", detectAntiBot);
} else {
    detectAntiBot();
}