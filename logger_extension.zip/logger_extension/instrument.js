(() => {
    // Helper for JSONifying objects
    function serializeObject(object, stringifyFunctions=false) {
        // Handle permissions errors
        try {
            if (object == null)
                return "null";

            if (typeof object == "function") {
                if (stringifyFunctions)
                    return object.toString();
                else
                    return "FUNCTION";
            }

            if (typeof object != "object")
                return object;

            var seenObjects = [];
            return JSON.stringify(object, function(key, value) {
                if(value == null)
                    return "null";

                if (typeof value == "function") {
                    if (stringifyFunctions)
                        return value.toString();
                    else
                        return "FUNCTION";
                }

                if(typeof value == "object") {
                    // Remove wrapping on content objects
                    if ("wrappedJSObject" in value) {
                        value = value.wrappedJSObject;
                    }

                    // Serialize DOM elements
                    if (value instanceof HTMLElement)
                        return "HTMLElement";
                        // return getPathToDomElement(value);

                    // Prevent serialization cycles
                    if (key == "" || seenObjects.indexOf(value) < 0) {
                        seenObjects.push(value);
                        return value;
                    } else {
                        return typeof value;
                    }
                }
                return value;
            });
        } catch(error) {
            // console.log("SERIALIZATION ERROR: " + error);
            return "SERIALIZATION ERROR: " + error;
        }
    }

    function logErrorToConsole(error) {
        console.log("Error name: " + error.name);
        console.log("Error message: " + error.message);
        console.log("Error filename: " + error.fileName);
        console.log("Error line number: " + error.lineNumber);
        console.log("Error stack: " + error.stack);
    }

    // Helper to get originating script urls
    function getStackTrace() {
        var stack;

        try {
            throw new Error();
        } catch (err) {
            stack = err.stack;
        }

        return stack;
    }

    // from http://stackoverflow.com/a/5202185
    String.prototype.rsplit = function(sep, maxsplit) {
        var split = this.split(sep);
        return maxsplit ? [split.slice(0, -maxsplit).join(sep)].concat(split.slice(-maxsplit)) : split;
    }

    function getOriginatingScriptURL(getCallStack=false) {
        var trace = getStackTrace().trim().split('\n');
        var url = "";
        for (let i = 0; i < trace.length; i++) {
            var line_split = trace[i].split("at ");
            if (line_split.length == 0) {
                continue;
            }

            const possible_url = line_split[line_split.length - 1];
            if (possible_url.startsWith("http")){
                url = possible_url.split(/:[0-9]/)[0];
                break;
            }
            
            if (possible_url.includes("(http")){
                url = possible_url.split("(")[1];
                url = url.split(/:[0-9]/)[0];
                break;
            }
        }

        return url;
    }

    // Counter to cap # of calls logged for each api (at the website level)
    var maxLogCount = 1000;
    var apiCounter = new Object();
    function updateAPICounterAndCheckIfOver(symbol) {
        var key = symbol;
        if ((key in apiCounter) && (apiCounter[key] >= maxLogCount)) {
            return true;
        } else if (!(key in apiCounter)) {
            apiCounter[key] = 1;
        } else {
            apiCounter[key] += 1;
        }
        return false;
    }

    // Counter to cap # of calls logged for each script/api combination
    var lowCapmaxLogCount = 50;
    var HighcapmaxLogCount = 500;
    var scriptCounter = new Object();
    // Define caps for symbols, not all symbols require 500 calls
    var highCapSymbols = ["CanvasRenderingContext2D.measureText", "CanvasRenderingContext2D.font"];

    function updateCounterAndCheckIfOver(scriptUrl, symbol) {
        var key = scriptUrl + '|' + symbol;
        if ((highCapSymbols.indexOf(symbol) === -1) && (key in scriptCounter) && (scriptCounter[key] >= lowCapmaxLogCount)) {
            return true;
        } else if ((highCapSymbols.indexOf(symbol) > -1) && (key in scriptCounter) && (scriptCounter[key] >= HighcapmaxLogCount)) {
            return true;
        } else if (!(key in scriptCounter)) {
            scriptCounter[key] = 1;
        } else {
            scriptCounter[key] += 1;
        }
        return false;
    }

    // Prevent logging of gets arising from logging
    var inLog = false;

    var custom_feat_apis = ['canvasrenderingcontext2d.font', 'webgl2renderingcontext.pixelstorei', 'htmlcanvaselement.isconnected', 'webglrenderingcontext.enable', 'htmlcanvaselement.offsetheight', 'htmlcanvaselement.clientheight', 'canvasrenderingcontext2d.globalcompositeoperation', 'canvasrenderingcontext2d.shadowcolor', 'webglrenderingcontext.disablevertexattribarray', 'htmlcanvaselement.outerhtml', 'webgl2renderingcontext.drawarrays', 'canvasrenderingcontext2d.drawimage', 'webgl2renderingcontext.bindrenderbuffer', 'webgl2renderingcontext.bindframebuffer', 'analysernode.numberofinputs', 'rtcpeerconnection.setlocaldescription', 'webglrenderingcontext.getactiveuniform', 'webglrenderingcontext.blendequationseparate', 'rtcpeerconnection.icegatheringstate', 'analysernode.channelcountmode', 'webgl2renderingcontext.teximage2d', 'webglrenderingcontext.getextension', 'webgl2renderingcontext.blendfunc', 'webgl2renderingcontext.bufferdata', 'webglactiveinfo.size', 'webglrenderingcontext.framebuffertexture2d', 'audiocontext.state', 'rtcpeerconnection.localdescription', 'canvasrenderingcontext2d.shadowoffsetx', 'canvasrenderingcontext2d.linedashoffset', 'htmlcanvaselement.classname', 'webglrenderingcontext.disable', 'webglrenderingcontext.cullface', 'canvasrenderingcontext2d.arcto', 'webgl2renderingcontext.cleardepth', 'htmlcanvaselement.draggable', 'htmlcanvaselement.nodename', 'webglrenderingcontext.getparameter', 'htmlcanvaselement.getelementsbytagname', 'webgl2renderingcontext.blendequation', 'webgl2renderingcontext.drawingbufferheight', 'webglrenderingcontext.colormask', 'analysernode.channelinterpretation', 'webgl2renderingcontext.getshaderprecisionformat', 'webgl2renderingcontext.getactiveattrib', 'navigator.vibrate', 'canvasrenderingcontext2d.textbaseline', 'htmlcanvaselement.clientwidth', 'webgl2renderingcontext.getuniformlocation', 'webgl2renderingcontext.activetexture', 'canvasrenderingcontext2d.shadowoffsety', 'analysernode.smoothingtimeconstant', 'webglrenderingcontext.texparameteri', 'window.localstorage', 'window.storage.setitem', 'canvasrenderingcontext2d.createimagedata', 'webglrenderingcontext.bindframebuffer', 'webglrenderingcontext.bindrenderbuffer', 'webgl2renderingcontext.getparameter', 'offlineaudiocontext.samplerate', 'webglrenderingcontext.bindtexture', 'webgl2renderingcontext.stencilmask', 'webglrenderingcontext.bindattriblocation', 'canvasrenderingcontext2d.stroketext', 'htmlcanvaselement.innertext', 'canvasrenderingcontext2d.strokerect', 'webglrenderingcontext.viewport', 'htmlcanvaselement.scrollwidth', 'webgl2renderingcontext.bindbuffer', 'webglrenderingcontext.getshaderparameter', 'webgl2renderingcontext.clearstencil', 'webglrenderingcontext.stencilmask', 'webgl2renderingcontext.viewport', 'htmlcanvaselement.scrollheight', 'webglrenderingcontext.clearcolor', 'canvasrenderingcontext2d.arc', 'webglrenderingcontext.clear', 'webglrenderingcontext.hint', 'canvasrenderingcontext2d.createlineargradient', 'rtcpeerconnection.signalingstate', 'htmlcanvaselement.offsettop', 'htmlcanvaselement.offsetparent', 'webglrenderingcontext.drawingbufferheight', 'htmlcanvaselement.offsetwidth', 'webgl2renderingcontext.getattriblocation', 'canvasrenderingcontext2d.linejoin', 'htmlcanvaselement.scrolltop', 'audiocontext.createdelay', 'webgl2renderingcontext.uniform2f', 'canvasrenderingcontext2d.fillstyle', 'webglrenderingcontext.depthfunc', 'analysernode.frequencybincount', 'webglrenderingcontext.getprogramparameter', 'node.childnodes', 'offlineaudiocontext.createscriptprocessor', 'audiocontext.createmediaelementsource', 'webglrenderingcontext.checkframebufferstatus', 'analysernode.fftsize', 'webglrenderingcontext.cleardepth', 'webglrenderingcontext.pixelstorei', 'webglrenderingcontext.blendfunc', 'webglrenderingcontext.teximage2d', 'audiocontext.createbuffer', 'analysernode.channelcount', 'webglrenderingcontext.scissor', 'canvasrenderingcontext2d.lineto', 'oscillatornode.type', 'webglrenderingcontext.buffersubdata', 'htmlcanvaselement.offsetleft', 'analysernode.maxdecibels', 'htmlcanvaselement.localname', 'canvasrenderingcontext2d.getimagedata', 'canvasrenderingcontext2d.textalign', 'HTMLCanvasElement.width', 'webglrenderingcontext.drawingbufferwidth', 'webglrenderingcontext.getactiveattrib', 'webglrenderingcontext.uniform2f', 'audiocontext.createchannelmerger', 'webgl2renderingcontext.generatemipmap', 'canvasrenderingcontext2d.mozimagesmoothingenabled', 'htmlcanvaselement.dir', 'webglcontextevent.hasownproperty', 'webgl2renderingcontext.cullface', 'webglrenderingcontext.depthmask', 'canvasrenderingcontext2d.putimagedata', 'webglrenderingcontext.readpixels', 'webglrenderingcontext.activetexture', 'webglrenderingcontext.blendfuncseparate', 'canvasrenderingcontext2d.filltext', 'webgl2renderingcontext.getshaderparameter', 'webgl2renderingcontext.drawingbufferwidth', 'canvasrenderingcontext2d.linecap', 'htmlcanvaselement.nextelementsibling', 'canvasrenderingcontext2d.linewidth', 'htmlcanvaselement.style', 'webglrenderingcontext.getattriblocation', 'canvasrenderingcontext2d.createpattern', 'canvasrenderingcontext2d.moveto', 'webglrenderingcontext.getshaderprecisionformat', 'webgl2renderingcontext.createshader', 'HTMLCanvasElement.height', 'window.sessionstorage', 'canvasrenderingcontext2d.beziercurveto', 'canvasrenderingcontext2d.clearrect', 'analysernode.mindecibels', 'canvasrenderingcontext2d.imagesmoothingenabled', 'htmlcanvaselement.attributes', 'canvasrenderingcontext2d.shadowblur', 'webgl2renderingcontext.drawelements', 'node.nodename', 'webglrenderingcontext.clearstencil', 'webgl2renderingcontext.getprogramparameter', 'document.getelementsbytagname', 'webgl2renderingcontext.vertexattribpointer', 'canvasrenderingcontext2d.quadraticcurveto', 'webgl2renderingcontext.depthmask', 'canvasrenderingcontext2d.miterlimit', 'webglrenderingcontext.stencilop', 'webglrenderingcontext.createshader', 'canvasrenderingcontext2d.fillrect', 'htmlcanvaselement.nodetype', 'htmlcanvaselement.clientleft', 'canvasrenderingcontext2d.rect', 'htmlcanvaselement.textcontent', 'window.storage.length', 'htmlcanvaselement.parentnode', 'webglactiveinfo.type', 'canvasrenderingcontext2d.strokestyle', 'webgl2renderingcontext.disable', 'webgl2renderingcontext.readpixels', 'webglrenderingcontext.bindbuffer', 'webglrenderingcontext.renderbufferstorage', 'webglrenderingcontext.frontface', 'canvasrenderingcontext2d.setlinedash', 'webglrenderingcontext.drawarrays', 'webglrenderingcontext.linewidth', 'canvasrenderingcontext2D.globalalpha', 'webgl2renderingcontext.clear', 'webglrenderingcontext.vertexattribpointer', 'canvasrenderingcontext2d.createradialgradient', 'canvasrenderingcontext2d.filter', 'webglrenderingcontext.drawelements', 'canvasrenderingcontext2d.translate', 'webglrenderingcontext.framebufferrenderbuffer', 'webglrenderingcontext.blendcolor', 'webglrenderingcontext.getuniformlocation', 'audiocontext.samplerate', 'node.isconnected', 'htmlcanvaselement.comparedocumentposition', 'webglrenderingcontext.blendequation', 'htmlcanvaselement.parentelement', 'webgl2renderingcontext.texparameteri', 'webgl2renderingcontext.clearcolor', 'webgl2renderingcontext.framebuffertexture2d', 'htmlcanvaselement.scrollleft', 'webgl2renderingcontext.getextension', 'webgl2renderingcontext.enable', 'webgl2renderingcontext.stencilop', 'window.document.cookie', 'webgl2renderingcontext.bindtexture', 'webglrenderingcontext.generatemipmap', 'htmlcanvaselement.clienttop', 'canvasrenderingcontext2d.measuretext', 'audiocontext.createscriptprocessor', 'analysernode.numberofoutputs', 'webgl2renderingcontext.getactiveuniform', 'node.nodetype', 'webgl2renderingcontext.depthfunc', 'webglrenderingcontext.bufferdata'];
    var value_length_features = [
        'htmlcanvaselement.parentnode',
        'htmlcanvaselement.nextelementsibling',
        'htmlcanvaselement.offsetparent',
        'htmlcanvaselement.textcontent',
        'htmlcanvaselement.outerhtml',
        'htmlcanvaselement.innertext',
        'htmlcanvaselement.parentelement'
    ];

    var value_json_length_features = [
        'window.localstorage',
        'window.sessionstorage',
        'htmlcanvaselement.style',
        'rtcpeerconnection.localdescription',
        'htmlcanvaselement.attributes',
        'node.childnodes'
    ];

    var arguments_length_features = [
        'rtcpeerconnection.setlocaldescription',
        'audiocontext.createmediaelementsource',
        'htmlcanvaselement.comparedocumentposition',
        'canvasrenderingcontext2d.measuretext',
        'navigator.vibrate'
    ];

    var argument_json_length_features = ['window.storage.setitem'];

    // For gets, sets, etc. on a single value
    function logValue(instrumentedVariableName, value, operation, scriptURL, logSettings) {
        if (inLog)
            return;
        inLog = true;

        var overLimit = updateCounterAndCheckIfOver(scriptURL, instrumentedVariableName);
        if (overLimit) {
            inLog = false;
            return;
        }

        // do not serialize value if it is not necessary for custom features
        var serializedValue = "";
        var symbolName = instrumentedVariableName.toLowerCase();
        if (custom_feat_apis.includes(symbolName))  {
            serializedValue = serializeObject(value, !!logSettings.logFunctionsAsStrings);

            if (value_length_features.includes(symbolName)) {
                // serialize the length of the value directly
                serializedValue = `{"extractedValue": ${serializedValue.length}}`;
            } else if (value_json_length_features.includes(symbolName)) {
                // serialize the length of the parsed object directly
                serializedValue = `{"extractedValue": ${Object.keys(JSON.parse(serializedValue)).length}}`;
            } else if (symbolName == 'window.document.cookie') {
                // serialize number of cookies directly
                serializedValue = `{"extractedValue": ${serializedValue.split(';').length}}`
            }
        }

        var msg = {
            operation: operation,
            symbol: instrumentedVariableName,
            value: serializedValue,
            arguments: JSON.stringify({}),
        };

        try {
            window.postMessage({ type: "LOG_CRAWL_F9743", data: { scriptURL: scriptURL, msg: msg } });
        } catch(error) {
            console.log("Unsuccessful value log!");
            logErrorToConsole(error);
        }

        inLog = false;
    }

    // For functions
    function logCall(instrumentedFunctionName, args, scriptURL, logSettings, originalObject) {
        if(inLog)
            return;
        inLog = true;

        var overLimit = updateCounterAndCheckIfOver(scriptURL, instrumentedFunctionName);
        if (overLimit) {
            inLog = false;
            return;
        }

        try {
            // do not serialize arguments if it is not necessary for custom features
            var serializedArgs = JSON.stringify({});
            var symbolName = instrumentedFunctionName.toLowerCase();
            if (custom_feat_apis.includes(symbolName)) {
                // Convert special arguments array to a standard array for JSONifying
                var serialArgs = [ ];
                for (var i = 0; i < args.length; i++)
                    serialArgs.push(serializeObject(args[i], !!logSettings.logFunctionsAsStrings));
                
                // Create a json object for function arguments
                // We create an object that maps array positon to argument
                // e.g. someFunc('a',123,'b') --> {0: a, 1: 123, 2: 'b'}
                // to make it easier to query the data, using something like the
                // sqlite3 json1 extension.
                var arguments = {};
                for (var i = 0; i < serialArgs.length; i++) {
                    arguments[i] = serialArgs[i]
                }

                serializedArgs = JSON.stringify(arguments);

                if (arguments_length_features.includes(symbolName)) {
                    // serialize the length of arguments directly
                    serializedArgs = `{"extractedValue": ${serializedArgs.length}}`;
                } else if (argument_json_length_features.includes(symbolName)) {
                    // serialize the length of the parsed object directly
                    serializedArgs = `{"extractedValue": ${Object.keys(JSON.parse(serializedArgs)).length}}`;
                }
            }

            var msg = {
                operation: "call",
                symbol: instrumentedFunctionName,
                arguments: serializedArgs,
                value: "",
            }

            window.postMessage({ type: "LOG_CRAWL_F9743", data: { scriptURL: scriptURL, msg: msg } });
        } catch(error) {
            console.log("Unsuccessful call log: " + instrumentedFunctionName);
            logErrorToConsole(error);
        }
        inLog = false;
    }

    // Rough implementations of Object.getPropertyDescriptor and Object.getPropertyNames
    // See http://wiki.ecmascript.org/doku.php?id=harmony:extended_object_api
    Object.getPropertyDescriptor = function (subject, name) {
        var pd = Object.getOwnPropertyDescriptor(subject, name);
        var proto = Object.getPrototypeOf(subject);
        while (pd === undefined && proto !== null) {
            pd = Object.getOwnPropertyDescriptor(proto, name);
            proto = Object.getPrototypeOf(proto);
        }
        return pd;
    };

    Object.getPropertyNames = function (subject, name) {
        var props = Object.getOwnPropertyNames(subject);
        var proto = Object.getPrototypeOf(subject);
        while (proto !== null) {
            props = props.concat(Object.getOwnPropertyNames(proto));
            proto = Object.getPrototypeOf(proto);
        }
        // FIXME: remove duplicate property names from props
        return props;
    };

    /*
    *  Direct instrumentation of javascript objects
    */

    function isObject(object, propertyName) {
        try {
            var property = object[propertyName];
        } catch(error) {
            return false;
        }

        if (property === null) { // null is type "object"
            return false;
        }
        return typeof property === 'object';
    }

    function instrumentObject(object, objectName, logSettings={}) {
        // Use for objects or object prototypes
        //
        // Parameters
        // ----------
        //   object : Object
        //     Object to instrument
        //   objectName : String
        //     Name of the object to be instrumented (saved to database)
        //   logSettings : Object
        //     (optional) object that can be used to specify additional logging
        //     configurations. See available options below.
        //
        // logSettings options (all optional)
        // -------------------
        //   propertiesToInstrument : Array
        //     An array of properties to instrument on this object. Default is
        //     all properties.
        //   excludedProperties : Array
        //     Properties excluded from instrumentation. Default is an empty
        //     array.
        //   logCallStack : boolean
        //     Set to true save the call stack info with each property call.
        //     Default is `false`.
        //   logFunctionsAsStrings : boolean
        //     Set to true to save functional arguments as strings during
        //     argument serialization. Default is `false`.
        //   preventSets : boolean
        //     Set to true to prevent nested objects and functions from being
        //     overwritten (and thus having their instrumentation removed).
        //     Other properties (static values) can still be set with this is
        //     enabled. Default is `false`.
        //   recursive : boolean
        //     Set to `true` to recursively instrument all object properties of
        //     the given `object`. Default is `false`
        //     NOTE:
        //       (1)`logSettings['propertiesToInstrument']` does not propagate
        //           to sub-objects.
        //       (2) Sub-objects of prototypes can not be instrumented
        //           recursively as these properties can not be accessed
        //           until an instance of the prototype is created.
        //   depth : integer
        //     Recursion limit when instrumenting object recursively.
        //     Default is `5`.
        var properties = logSettings.propertiesToInstrument ? logSettings.propertiesToInstrument : Object.getPropertyNames(object);
        for (var i = 0; i < properties.length; i++) {
            if (logSettings.excludedProperties &&
                logSettings.excludedProperties.indexOf(properties[i]) > -1) {
                continue;
            }

            // If `recursive` flag set we want to recursively instrument any
            // object properties that aren't the prototype object. Only recurse if
            // depth not set (at which point its set to default) or not at limit.
            if (!!logSettings.recursive && properties[i] != '__proto__' &&
                isObject(object, properties[i]) &&
                (!('depth' in logSettings) || logSettings.depth > 0)) {

                // set recursion limit to default if not specified
                if (!('depth' in logSettings)) {
                    logSettings['depth'] = 5;
                }
                instrumentObject(object[properties[i]], objectName + '.' + properties[i], {
                    'excludedProperties': logSettings['excludedProperties'],
                    'logCallStack': logSettings['logCallStack'],
                    'logFunctionsAsStrings': logSettings['logFunctionsAsStrings'],
                    'preventSets': logSettings['preventSets'],
                    'recursive': logSettings['recursive'],
                    'depth': logSettings['depth'] - 1
                });
            }

            try {
                instrumentObjectProperty(object, objectName, properties[i], logSettings);
            } catch(error) {
                logErrorToConsole(error);
            }
        }
    }

    // Log calls to a given function
    // This helper function returns a wrapper around `func` which logs calls
    // to `func`. `objectName` and `methodName` are used strictly to identify
    // which object method `func` is coming from in the logs
    function instrumentFunction(objectName, methodName, func, logSettings, originalObject) {
        return function () {
            var instrumentedFunctionName = objectName + '.' + methodName;
            if (!updateAPICounterAndCheckIfOver(instrumentedFunctionName)) {
                var scriptURL = getOriginatingScriptURL(!!logSettings.logCallStack);
                logCall(instrumentedFunctionName, arguments, scriptURL, logSettings, originalObject);
            }

            return func.apply(this, arguments);
        };
    }

    // Log properties of prototypes and objects
    function instrumentObjectProperty(object, objectName, propertyName, logSettings={}) {
        // Store original descriptor in closure
        var propDesc = Object.getPropertyDescriptor(object, propertyName);
        if (!propDesc){
            // console.error("Property descriptor not found for", objectName, propertyName, object);
            return;
        }

        // Instrument data or accessor property descriptors
        var originalGetter = propDesc.get;
        var originalSetter = propDesc.set;
        var originalValue = propDesc.value;

        // We overwrite both data and accessor properties as an instrumented
        // accessor property
        Object.defineProperty(object, propertyName, {
            configurable: true,
            get: (function() {
                return function() {
                    var origProperty;
                    var instrumentedVariableName = objectName + '.' + propertyName; 

                    // get original value
                    if (originalGetter) { // if accessor property
                        origProperty = originalGetter.call(this);
                    } else if ('value' in propDesc) { // if data property
                        origProperty = originalValue;
                    } else {
                        if (!updateAPICounterAndCheckIfOver(instrumentedVariableName)) {
                            var scriptURL = getOriginatingScriptURL(!!logSettings.logCallStack);
                            logValue(instrumentedVariableName, "",
                                "get(failed)", scriptURL, logSettings);
                        }

                        console.log("Property descriptor for",
                                    objectName + '.' + propertyName,
                                    "doesn't have getter or value?");
                        return;
                    }

                    // Log `gets` except those that have instrumented return values
                    // * All returned functions are instrumented with a wrapper
                    // * Returned objects may be instrumented if recursive
                    //   instrumentation is enabled and this isn't at the depth limit.
                    if (typeof origProperty == 'function') {
                        // `this` object here has is the one on which method/event is called
                        return instrumentFunction(objectName, propertyName, origProperty, logSettings, this);
                    } else if (typeof origProperty == 'object' &&
                        !!logSettings.recursive &&
                        (!('depth' in logSettings) || logSettings.depth > 0)) {
                        return origProperty;
                    } else {
                        if (!updateAPICounterAndCheckIfOver(instrumentedVariableName)) {
                            var scriptURL = getOriginatingScriptURL(!!logSettings.logCallStack);
                            logValue(instrumentedVariableName, origProperty,
                                "get", scriptURL, logSettings);
                        }
                        return origProperty;
                    }
                }
            })(),
            set: (function() {
                return function(value) {
                    var returnValue;
                    var instrumentedVariableName = objectName + '.' + propertyName; 

                    // Prevent sets for functions and objects if enabled
                    if (!!logSettings.preventSets && (
                        typeof originalValue === 'function' ||
                        typeof originalValue === 'object')) {
                        if (!updateAPICounterAndCheckIfOver(instrumentedVariableName)) {
                            var scriptURL = getOriginatingScriptURL(!!logSettings.logCallStack);
                            logValue(instrumentedVariableName, value,
                                "set(prevented)", scriptURL, logSettings);
                        }
                        return value;
                    }

                    // set new value to original setter/location
                    if (originalSetter) { // if accessor property
                        returnValue = originalSetter.call(this, value);
                    } else if ('value' in propDesc) { // if data property
                        inLog = true;
                        if (object.isPrototypeOf(this)) {
                            Object.defineProperty(this, propertyName, {
                                value: value
                            });
                        } else {
                            originalValue = value;
                        }
                        returnValue = value;
                        inLog = false;
                    } else {
                        if (!updateAPICounterAndCheckIfOver(instrumentedVariableName)) {
                            var scriptURL = getOriginatingScriptURL(!!logSettings.logCallStack);
                            logValue(instrumentedVariableName, value,
                                "set(failed)", scriptURL, logSettings);
                        }
                        console.log("Property descriptor for",
                                    instrumentedVariableName,
                                    "doesn't have setter or value?");
                        return value;
                    }

                    // log set
                    if (!updateAPICounterAndCheckIfOver(instrumentedVariableName)) {
                        var scriptURL = getOriginatingScriptURL(!!logSettings.logCallStack);
                        logValue(instrumentedVariableName, value,
                            "set", scriptURL, logSettings);
                    }

                    // return new value
                    return returnValue;
                }
            })()
        });
    }

    /*
    * Start Instrumentation
    */
    // TODO: user should be able to choose what to instrument

    // Access to plugins
    var pluginProperties = [ "name", "filename", "description", "version", "length"];
    for (var i = 0; i < window.navigator.plugins.length; i++) {
        let pluginName = window.navigator.plugins[i].name;
        pluginProperties.forEach(function(property) {
        instrumentObjectProperty(
            window.navigator.plugins[pluginName],
            "window.navigator.plugins[" + pluginName + "]", property, {
                logCallStack: true
            });
        });
    }

    // Access to MIMETypes
    var mimeTypeProperties = [ "description", "suffixes", "type"];
    for (var i = 0; i < window.navigator.mimeTypes.length; i++) {
        let mimeTypeName = window.navigator.mimeTypes[i].type;
        mimeTypeProperties.forEach(function(property) {
        instrumentObjectProperty(
            window.navigator.mimeTypes[mimeTypeName],
            "window.navigator.mimeTypes[" + mimeTypeName + "]", property, {
                logCallStack: true
            });
        });
    }

    // Access to navigator properties
    var navigatorProperties = [ "appCodeName", "appName", "appVersion",
                                "cookieEnabled", "doNotTrack", "buildID",
                                "oscpu", "geolocation", "language", "languages",
                                "onLine", "platform", "product",
                                "productSub", "userAgent", "vendorSub",
                                "vendor", "javaEnabled", "permissions",
                                "pdfViewerEnabled", "webkitGetUserMedia", // high entropy
                                "mimeTypes", "getUserMedia", "hardwareConcurrency", // high entropy
                                "plugins", "deviceMemory", "maxTouchPoints" // high entropy
                                ];

    // Access to Navigator methods
    var navigatorPropertiesToInstrument = ["vibrate", "sendBeacon"];
    instrumentObject(
        window.Navigator.prototype,
        "Navigator",
        {'propertiesToInstrument': navigatorPropertiesToInstrument, 
        logCallStack: true}
    );

    navigatorProperties.forEach(function(property) {
        instrumentObjectProperty(window.navigator, "window.navigator", property, {
        logCallStack: true
        });
    });

    // Access to screen properties
    //instrumentObject(window.screen, "window.screen");
    // TODO: why do we instrument only two screen properties
    var screenProperties =  [ "pixelDepth", "colorDepth",  
                                "orientation", "availHeight", "availLeft", "availTop", "availWidth", // high entropy
                                "height", "isExtended", "onchange", "width" ] // high entropy
    screenProperties.forEach(function(property) {
        instrumentObjectProperty(window.screen, "window.screen", property, {
        logCallStack: true
        });
    });

    // Name, localStorage, and sessionsStorage logging
    // Instrumenting window.localStorage directly doesn't seem to work, so the Storage
    // prototype must be instrumented instead. Unfortunately this fails to differentiate
    // between sessionStorage and localStorage. Instead, you'll have to look for a sequence
    // of a get for the localStorage object followed by a getItem/setItem for the Storage object.
    var windowProperties = [ "name", "localStorage", "sessionStorage", 
                            "devicePixelRatio", "innerHeight", "innerWidth", "matchMedia", // high entropy
                            "outerHeight", "outerWidth", "pageXOffset", "pageYOffset", // high entropy
                            "screenLeft", "screenTop", "screenX", "screenY", "scrollX", "scrollY" // high entropy
                            ];
    windowProperties.forEach(function(property) {
        instrumentObjectProperty(window, "window", property, {
        logCallStack: true
        });
    });
    instrumentObject(window.Storage.prototype, "window.Storage", {
        logCallStack: true
    });

    // Access to document.cookie
    instrumentObjectProperty(window.document, "window.document", "cookie", {
        logCallStack: true
    });

    // Access to canvas
    instrumentObject(window.HTMLCanvasElement.prototype,"HTMLCanvasElement", {logCallStack: true});

    // var excludedProperties = [ "quadraticCurveTo", "lineTo", "transform",
    //                            "globalAlpha", "moveTo", "drawImage",
    //                            "setTransform", "clearRect", "closePath",
    //                            "beginPath", "canvas", "translate" ];
    instrumentObject(
        window.CanvasRenderingContext2D.prototype,
        "CanvasRenderingContext2D",
        {logCallStack: true}
    );

    // Access to webRTC
    instrumentObject(window.RTCPeerConnection.prototype,"RTCPeerConnection", {
        logCallStack: true
    });

    // Access to Audio API
    instrumentObject(window.AudioContext.prototype, "AudioContext", {
        logCallStack: true
    });
    instrumentObject(window.OfflineAudioContext.prototype, "OfflineAudioContext", {
        logCallStack: true
    });
    instrumentObject(window.OscillatorNode.prototype, "OscillatorNode", {
        logCallStack: true
    });
    instrumentObject(window.AnalyserNode.prototype, "AnalyserNode", {
        logCallStack: true
    });
    instrumentObject(window.GainNode.prototype, "GainNode", {
        logCallStack: true
    });
    instrumentObject(window.ScriptProcessorNode.prototype, "ScriptProcessorNode", {
        logCallStack: true
    });


    var includedWebGLProperties = [ "canvas", "drawingBufferWidth", "drawingBufferHeight", "getContextAttributes", "isContextLost", 
                                "scissor", "viewport", "activeTexture", "blendColor", "blendEquation", "blendEquationSeparate",
                                "blendFunc", "blendFuncSeparate", "clearColor", "clearDepth", "clearStencil", "colorMask", "cullFace",
                                "depthFunc", "depthMask", "depthRange", "disable", "enable", "frontFace", "getParameter", "getError",
                                "hint", "isEnabled", "lineWidth", "pixelStorei", "polygonOffset", "sampleCoverage", "stencilFunc", "stencilFuncSeparate",
                                "stencilMask", "stencilMaskSeparate", "stencilOp", "stencilOpSeparate", "bindBuffer", "bufferData", 
                                "bufferSubData", "createBuffer", "deleteBuffer", "getBufferParameter", "isBuffer", "bindFramebuffer", 
                                "checkFramebufferStatus", "createFramebuffer", "deleteFramebuffer", "framebufferRenderbuffer", 
                                "framebufferTexture2D", "getFramebufferAttachmentParameter", "isFramebuffer", "readPixels", "bindRenderbuffer",
                                "createRenderbuffer", "deleteRenderbuffer", "getRenderbufferParameter", "isRenderbuffer", "renderbufferStorage",
                                "bindTexture", "compressedTexImage2D", "compressedTexSubImage2D", "copyTexImage2D", "copyTexSubImage2D",
                                "createTexture", "deleteTexture", "generateMipmap", "getTexParameter", "isTexture", "texImage2D", "texSubImage2D",
                                "texParameterf", "texParameteri", "attachShader", "bindAttribLocation", "compileShader", "createProgram", "createShader",
                                "deleteProgram", "deleteShader", "detachShader", "getAttachedShaders", "getProgramParameter", "getProgramInfoLog",
                                "getShaderParameter", "getShaderPrecisionFormat", "getShaderInfoLog", "getShaderSource", "isProgram", "isShader",
                                "linkProgram", "shaderSource", "useProgram", "validateProgram", "disableVertexAttribArray", "enableVertexAttribArray",
                                "getActiveAttrib", "getActiveUniform", "getAttribLocation", "getUniform", "getUniformLocation", "getVertexAttrib", 
                                "getVertexAttribOffset", "uniform1f", "uniform1fv", "uniform1i", "uniform1iv", "uniform2f", "uniform2fv", "uniform2i",
                                "uniform2iv", "uniform3f", "uniform3fv", "uniform3i", "uniform3iv", "uniform4f", "uniform4fv", "uniform4i", "uniform4iv", 
                                "uniformMatrix2fv", "uniformMatrix3fv", "uniformMatrix4fv", "vertexAttrib1f", "vertexAttrib2f", "vertexAttrib3f", "vertexAttrib4f",
                                "vertexAttrib1fv", "vertexAttrib2fv", "vertexAttrib3fv", "vertexAttrib4fv", "vertexAttribPointer", "clear", "drawArrays",
                                "drawElements", "finish", "flush", "getSupportedExtensions", "getExtension",
                                "getInternalformatParameter", "getRenderbufferParameter", "makeXRCompatible" // high entropy
                                ]

    // Access to WebGL
    instrumentObject(window.WebGLRenderingContext.prototype, "WebGLRenderingContext", {'propertiesToInstrument': includedWebGLProperties, logCallStack: true});
    instrumentObject(window.WebGL2RenderingContext.prototype, "WebGL2RenderingContext", {'propertiesToInstrument': includedWebGLProperties, logCallStack: true});

    instrumentObject(window.WebGLActiveInfo.prototype, "WebGLActiveInfo", {
        logCallStack: true
    });
    instrumentObject(window.WebGLBuffer.prototype, "WebGLBuffer", {
        logCallStack: true
    });
    instrumentObject(window.WebGLContextEvent.prototype, "WebGLContextEvent", {
        logCallStack: true
    });
    instrumentObject(window.WebGLFramebuffer.prototype, "WebGLFramebuffer", {
        logCallStack: true
    });
    instrumentObject(window.WebGLProgram.prototype, "WebGLProgram", {
        logCallStack: true
    });
    instrumentObject(window.WebGLQuery.prototype, "WebGLQuery", {
        logCallStack: true
    });
    instrumentObject(window.WebGLRenderbuffer.prototype, "WebGLRenderbuffer", {
        logCallStack: true
    });
    instrumentObject(window.WebGLSampler.prototype, "WebGLSampler", {
        logCallStack: true
    });
    instrumentObject(window.WebGLShader.prototype, "WebGLShader", {
        logCallStack: true
    });
    instrumentObject(window.WebGLShaderPrecisionFormat.prototype, "WebGLShaderPrecisionFormat", {
        logCallStack: true
    });
    instrumentObject(window.WebGLSync.prototype, "WebGLSync", {
        logCallStack: true
    });
    instrumentObject(window.WebGLTexture.prototype, "WebGLTexture", {
        logCallStack: true
    });
    instrumentObject(window.WebGLTransformFeedback.prototype, "WebGLTransformFeedback", {
        logCallStack: true
    });
    instrumentObject(window.WebGLUniformLocation.prototype, "WebGLUniformLocation", {
        logCallStack: true
    });
    instrumentObject(window.WebGLVertexArrayObject.prototype, "WebGLVertexArrayObject", {
        logCallStack: true
    });

    // Access to Animation
    instrumentObject(window.Animation.prototype, "Animation", {
        logCallStack: true
    });

    // Access to Node

    var excludedNodeProperties = [ "ELEMENT_NODE", "ATTRIBUTE_NODE", "TEXT_NODE",
                                "CDATA_SECTION_NODE", "ENTITY_REFERENCE_NODE", "ENTITY_NODE",
                                "PROCESSING_INSTRUCTION_NODE", "COMMENT_NODE", "DOCUMENT_NODE",
                                "DOCUMENT_TYPE_NODE", "DOCUMENT_FRAGMENT_NODE", "NOTATION_NODE",
                                "DOCUMENT_POSITION_DISCONNECTED", "DOCUMENT_POSITION_PRECEDING",
                                "DOCUMENT_POSITION_FOLLOWING", "DOCUMENT_POSITION_CONTAINS",
                                "DOCUMENT_POSITION_CONTAINED_BY", "DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC", "dispatchEvent" ];

    instrumentObject(window.Node.prototype, "Node", {'excludedProperties': excludedNodeProperties, logCallStack: true});

    // Access to Document
    var propertiesToInstrument = [ "createComment", "createDocumentFragment", "createElement",
                                    "createTextNode", "getElementsByClassName", "getElementsByTagName",
                                    "getElementById", "querySelector", "querySelectorAll"];
    instrumentObject(
        window.Document.prototype,
        "Document",
        {'propertiesToInstrument': propertiesToInstrument, logCallStack: true}
    );

    var includedPropertiesForEventTarget = [ "addEventListener"];
    var excludedPropertiesForEventTarget = [ "dispatchEvent"];

    instrumentObject(
        window.EventTarget.prototype,
        "EventTarget",
        {'propertiesToInstrument': includedPropertiesForEventTarget,
        'excludedProperties': excludedPropertiesForEventTarget,
        logCallStack: true}
    );

    // Access to Performance methods
    var performanceePropertiesToInstrument = [ "now"];
    instrumentObject(
        window.Performance.prototype,
        "Performance",
        {'propertiesToInstrument': performanceePropertiesToInstrument, logCallStack: true}
    );

    // high entropy instrumentations
    window.AudioBuffer !== undefined && instrumentObject(window.AudioBuffer.prototype, "AudioBuffer", {'propertiesToInstrument': ['copyFromChannel', 'getChannelData'], logCallStack: true});
    window.AuthenticatorAttestationResponse !== undefined && instrumentObject(window.AuthenticatorAttestationResponse.prototype, "AuthenticatorAttestationResponse", {'propertiesToInstrument': ['getTransports'], logCallStack: true});
    window.BackgroundFetchRegistration !== undefined && instrumentObject(window.BackgroundFetchRegistration.prototype, "BackgroundFetchRegistration", {'propertiesToInstrument': ['failureReason'], logCallStack: true});
    window.BaseAudioContext !== undefined && instrumentObject(window.BaseAudioContext.prototype, "BaseAudioContext", {'propertiesToInstrument': ['sampleRate'], logCallStack: true});
    window.BatteryManager !== undefined && instrumentObject(window.BatteryManager.prototype, "BatteryManager", {'propertiesToInstrument': ['charging', 'chargingTime', 'dischargingTime', 'level'], logCallStack: true});
    window.BeforeInstallPromptEvent !== undefined && instrumentObject(window.BeforeInstallPromptEvent.prototype, "BeforeInstallPromptEvent", {'propertiesToInstrument': ['platforms'], logCallStack: true});
    window.BluetoothAdvertisingEvent !== undefined && instrumentObject(window.BluetoothAdvertisingEvent.prototype, "BluetoothAdvertisingEvent", {'propertiesToInstrument': ['appearance', 'name', 'txPower'], logCallStack: true});
    window.BluetoothDevice !== undefined && instrumentObject(window.BluetoothDevice.prototype, "BluetoothDevice", {'propertiesToInstrument': ['name'], logCallStack: true});
    window.FeaturePolicy !== undefined && instrumentObject(window.FeaturePolicy.prototype, "FeaturePolicy", {'propertiesToInstrument': ['features'], logCallStack: true});
    window.Gamepad !== undefined && instrumentObject(window.Gamepad.prototype, "Gamepad", {'propertiesToInstrument': ['id'], logCallStack: true});
    window.History !== undefined && instrumentObject(window.History.prototype, "History", {'propertiesToInstrument': ['length'], logCallStack: true});
    window.HTMLMediaElement !== undefined && instrumentObject(window.HTMLMediaElement.prototype, "HTMLMediaElement", {'propertiesToInstrument': ['canPlayType'], logCallStack: true});
    window.HTMLVideoElement !== undefined && instrumentObject(window.HTMLVideoElement.prototype, "HTMLVideoElement", {'propertiesToInstrument': ['webkitDecodedFrameCount', 'webkitDroppedFrameCount'], logCallStack: true});
    window.InputDeviceCapabilities !== undefined && instrumentObject(window.InputDeviceCapabilities.prototype, "InputDeviceCapabilities", {'propertiesToInstrument': ['firesTouchEvents'], logCallStack: true});
    window.Keyboard !== undefined && instrumentObject(window.Keyboard.prototype, "Keyboard", {'propertiesToInstrument': ['getLayoutMap'], logCallStack: true});
    window.MediaDevices !== undefined && instrumentObject(window.MediaDevices.prototype, "MediaDevices", {'propertiesToInstrument': ['enumerateDevices', 'getUserMedia'], logCallStack: true});
    window.MediaRecorder !== undefined && instrumentObject(window.MediaRecorder.prototype, "MediaRecorder", {'propertiesToInstrument': ['audioBitsPerSecond', 'mimeType', 'videoBitsPerSecond'], logCallStack: true});
    window.MouseEvent !== undefined && instrumentObject(window.MouseEvent.prototype, "MouseEvent", {'propertiesToInstrument': ['screenX', 'screenY'], logCallStack: true});
    window.NavigatorUAData !== undefined && instrumentObject(window.NavigatorUAData.prototype, "NavigatorUAData", {'propertiesToInstrument': ['brands', 'getHighEntropyValues', 'mobile', 'platform', 'toJSON'], logCallStack: true});
    window.NetworkInformation !== undefined && instrumentObject(window.NetworkInformation.prototype, "NetworkInformation", {'propertiesToInstrument': ['saveData'], logCallStack: true});
    window.OffscreenCanvas !== undefined && instrumentObject(window.OffscreenCanvas.prototype, "OffscreenCanvas", {'propertiesToInstrument': ['convertToBlob', 'transferToImageBitmap'], logCallStack: true});
    window.OffscreenCanvasRenderingContext2D !== undefined && instrumentObject(window.OffscreenCanvasRenderingContext2D.prototype, "OffscreenCanvasRenderingContext2D", {'propertiesToInstrument': ['fillText', 'getImageData', 'isPointInPath', 'isPointInStroke', 'measureText'], logCallStack: true});
    window.PaintRenderingContext2D !== undefined && instrumentObject(window.PaintRenderingContext2D.prototype, "PaintRenderingContext2D", {'propertiesToInstrument': ['isPointInPath', 'isPointInStroke'], logCallStack: true});
    window.PaintWorkletGlobalScope !== undefined && instrumentObject(window.PaintWorkletGlobalScope.prototype, "PaintWorkletGlobalScope", {'propertiesToInstrument': ['devicePixelRatio'], logCallStack: true});
    window.PaymentRequest !== undefined && instrumentObject(window.PaymentRequest.prototype, "PaymentRequest", {'propertiesToInstrument': ['canMakePayment', 'hasEnrolledInstrument'], logCallStack: true});
    window.PushManager !== undefined && instrumentObject(window.PushManager, "PushManager", {'propertiesToInstrument': ['supportedContentEncodings'], logCallStack: true});
    window.RTCIceCandidate !== undefined && instrumentObject(window.RTCIceCandidate.prototype, "RTCIceCandidate", {'propertiesToInstrument': ['address', 'candidate', 'port', 'relatedAddress', 'relatedPort'], logCallStack: true});
    window.RTCRtpReceiver !== undefined && instrumentObject(window.RTCRtpReceiver, "RTCRtpReceiver", {'propertiesToInstrument': ['getCapabilities'], logCallStack: true});
    window.RTCRtpSender !== undefined && instrumentObject(window.RTCRtpSender, "RTCRtpSender", {'propertiesToInstrument': ['getCapabilities'], logCallStack: true});
    window.ScreenDetailed !== undefined && instrumentObject(window.ScreenDetailed.prototype, "ScreenDetailed", {'propertiesToInstrument': ['devicePixelRatio', 'isInternal', 'isPrimary', 'label', 'left', 'top'], logCallStack: true});
    window.ScreenDetails !== undefined && instrumentObject(window.ScreenDetails.prototype, "ScreenDetails", {'propertiesToInstrument': ['oncurrentscreenchange', 'onscreenschange'], logCallStack: true});
    window.ScreenOrientation !== undefined && instrumentObject(window.ScreenOrientation.prototype, "ScreenOrientation", {'propertiesToInstrument': ['angle', 'type'], logCallStack: true});
    window.SVGAnimationElement !== undefined && instrumentObject(window.SVGAnimationElement.prototype, "SVGAnimationElement", {'propertiesToInstrument': ['requiredExtensions', 'systemLanguage'], logCallStack: true});
    window.SVGGeometryElement !== undefined && instrumentObject(window.SVGGeometryElement.prototype, "SVGGeometryElement", {'propertiesToInstrument': ['getPointAtLength', 'getTotalLength', 'isPointInFill', 'isPointInStroke'], logCallStack: true});
    window.SVGGraphicsElement !== undefined && instrumentObject(window.SVGGraphicsElement.prototype, "SVGGraphicsElement", {'propertiesToInstrument': ['requiredExtensions', 'systemLanguage'], logCallStack: true});
    window.SVGMaskElement !== undefined && instrumentObject(window.SVGMaskElement.prototype, "SVGMaskElement", {'propertiesToInstrument': ['requiredExtensions', 'systemLanguage'], logCallStack: true});
    window.SVGPatternElement !== undefined && instrumentObject(window.SVGPatternElement.prototype, "SVGPatternElement", {'propertiesToInstrument': ['requiredExtensions', 'systemLanguage'], logCallStack: true});
    window.SVGTextContentElement !== undefined && instrumentObject(window.SVGTextContentElement.prototype, "SVGTextContentElement", {'propertiesToInstrument': ['getComputedTextLength', 'getEndPositionOfChar', 'getExtentOfChar', 'getStartPositionOfChar', 'getSubStringLength'], logCallStack: true});
    window.Touch !== undefined && instrumentObject(window.Touch.prototype, "Touch", {'propertiesToInstrument': ['force'], logCallStack: true});
    window.VisualViewport !== undefined && instrumentObject(window.VisualViewport.prototype, "VisualViewport", {'propertiesToInstrument': ['height', 'offsetLeft', 'offsetTop', 'pageLeft', 'pageTop', 'scale', 'width'], logCallStack: true});
    window.WebGLCompressedTextureASTC !== undefined && instrumentObject(window.WebGLCompressedTextureASTC.prototype, "WebGLCompressedTextureASTC", {'propertiesToInstrument': ['getSupportedProfiles'], logCallStack: true});
    window.WheelEvent !== undefined && instrumentObject(window.WheelEvent.prototype, "WheelEvent", {'propertiesToInstrument': ['deltaMode', 'wheelDelta', 'wheelDeltaX', 'wheelDeltaY'], logCallStack: true});
    window.WorkerNavigator !== undefined && instrumentObject(window.WorkerNavigator.prototype, "WorkerNavigator", {'propertiesToInstrument': ['appVersion', 'deviceMemory', 'hardwareConcurrency', 'language', 'languages', 'platform', 'userAgent'], logCallStack: true});

    console.log("Successfully started all instrumentation.");
})();