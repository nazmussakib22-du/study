// background.js
const LOCAL_SERVER_URL = "http://127.0.0.1:5000";

const ENABLE_CDP = true; // Toggle off when used alongside Puppeteer/Playwright/browser-use

async function loadTargetDomains() {
    try {
        const response = await fetch(chrome.runtime.getURL('clean_top_1000.txt'));
        const text = await response.text();
        TARGET_DOMAINS = text
            .split(/\r?\n/)
            .map(line => line.trim())
            .filter(line => line.length > 0);
    } catch (error) {
        console.error("Failed to load target domains list:", error);
    }
}

function isTargetUrl(url) {
    try {
        const hostname = new URL(url).hostname.toLowerCase();
        return TARGET_DOMAINS.some(domain => 
            hostname === domain || hostname.endsWith("." + domain)
        );
    } catch (e) {
        return false;
    }
}

// Change TARGET_DOMAINS from const to let (already done) and initialize empty:
let TARGET_DOMAINS = [];

loadTargetDomains();

const attachedTabs = new Set();
const requestMap = new Map(); // Maps requestId to request metadata

// Step 2: Track visit_id state
const tabVisitMap = new Map(); 

// ============================================================================
// 1. Python Server Transmission Logic
// ============================================================================

async function sendToServer(endpoint, payload) {
    try {
        await fetch(`${LOCAL_SERVER_URL}${endpoint}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
    } catch (e) {
        console.error(`Failed to send data to ${endpoint}:`, e);
    }
}

// ============================================================================
// 2. Debugger Attachment & Lifecycle
// ============================================================================

async function attachDebugger(tabId) {
    if (attachedTabs.has(tabId)) return;
    
    try {
        const tab = await chrome.tabs.get(tabId);
        const url = tab.url || tab.pendingUrl || "";

        if (url.startsWith("chrome://") || 
            url.startsWith("devtools://") || 
            url.startsWith("chrome-extension://")) {
            return;
        }

        await chrome.debugger.attach({ tabId }, "1.3");
        await chrome.debugger.sendCommand({ tabId }, "Network.enable");
        
        // ADDED: Enable auto-attach for OOPIFs
        await chrome.debugger.sendCommand({ tabId }, "Target.setAutoAttach", {
            autoAttach: true,
            waitForDebuggerOnStart: true,
            flatten: true
        });
        
        attachedTabs.add(tabId);
    } catch (e) {
        if (!e.message.includes("Cannot attach to this target")) {
            console.error(`Failed to attach debugger to tab ${tabId}:`, e);
        }
    }
}

// Ensure activated tabs also check domain filters before attaching
chrome.tabs.onActivated.addListener(async (activeInfo) => {
    if (!ENABLE_CDP) return;

    const tab = await chrome.tabs.get(activeInfo.tabId);
    try {
        const urlObj = new URL(tab.url || tab.pendingUrl);
        const isTarget = TARGET_DOMAINS.some(domain => 
            urlObj.hostname === domain || urlObj.hostname.endsWith("." + domain)
        );
        if (isTarget) attachDebugger(activeInfo.tabId);
    } catch (e) {}
});

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
    if (details.frameId === 0) {
        try {
            // Step 1: Extract hostname and filter
            const urlObj = new URL(details.url);
            const isTarget = TARGET_DOMAINS.some(domain => 
                urlObj.hostname === domain || urlObj.hostname.endsWith("." + domain)
            );

            if (!isTarget) return;

            // Step 2: Generate and Track visit_id State
            const newVisitId = crypto.randomUUID();
            tabVisitMap.set(details.tabId, newVisitId);
            
            if (ENABLE_CDP) {
            attachDebugger(details.tabId);
            }

            sendToServer("/log_event", {
                type: "VISIT_START",
                visit_id: newVisitId,
                url: details.url,
                timestamp: Date.now()
            });
        } catch(e) {
            // Ignore invalid URLs
        }
    }
});

// Step 4: Memory Management - Clear state when tabs close or detach
chrome.tabs.onRemoved.addListener((tabId) => {
    attachedTabs.delete(tabId);
    tabVisitMap.delete(tabId);
});

chrome.debugger.onDetach.addListener((source) => {
    attachedTabs.delete(source.tabId);
    tabVisitMap.delete(source.tabId);
});

// ============================================================================
// 3. Network Interception & WAF Logic
// ============================================================================

function shouldLogBody(mimeType, contentLength) {
    if (!mimeType) return true;
    
    if (mimeType.startsWith("image/") || mimeType.startsWith("video/") || mimeType.startsWith("audio/") || mimeType.startsWith("font/")) {
        return false;
    }
    
    const skipBinary = new Set(["application/octet-stream", "application/pdf", "application/zip", "application/x-zip-compressed"]);
    if (skipBinary.has(mimeType)) {
        return false;
    }
    
    if (contentLength && parseInt(contentLength, 10) > 262144) {
        return false;
    }
    return true;
}

// Step 3: Accept visitId as parameter
function detectWafHeaders(url, status, headers, visitId, isTarget) {
    const lowerHeaders = {};
    for (const [key, value] of Object.entries(headers)) {
        lowerHeaders[key.toLowerCase()] = value.toLowerCase();
    }

    const serverHeader = lowerHeaders["server"] || "";
    let wafName = null;

    if (serverHeader.includes("cloudflare") || lowerHeaders["cf-ray"]) {
        wafName = "Cloudflare";
    } else if (lowerHeaders["x-datadome"]) {
        wafName = "DataDome";
    } else if (lowerHeaders["x-px"]) {
        wafName = "PerimeterX";
    } else if (serverHeader.includes("akamai")) {
        wafName = "Akamai";
    } else if (lowerHeaders["x-iinfo"] || (lowerHeaders["x-cdn"] || "").includes("incapsula") || serverHeader.includes("incapsula")) {
        wafName = "Incapsula";
    }

    if (wafName) {
        sendToServer("/log_event", {
            type: "WAF_PASSED",
            visit_id: visitId,
            url: url,
            waf: wafName,
            status: status,
            scope: isTarget ? "target" : "third_party", // NEW
            timestamp: Date.now()
        });
    }
}

chrome.debugger.onEvent.addListener(async (source, method, params) => {
    // Step 3: Retrieve active visit ID, drop event if missing
    const currentVisitId = tabVisitMap.get(source.tabId);
    if (!currentVisitId) return;

    // NEW: enable Network on newly attached OOPIF/child targets so their
    // traffic actually flows into the handlers below. Without this,
    // setAutoAttach discovers the targets but never sees their requests.
    if (method === "Target.attachedToTarget") {
        const { sessionId, targetInfo } = params;
        if (["page", "iframe"].includes(targetInfo.type)) {
            try {
                await chrome.debugger.sendCommand(
                    { tabId: source.tabId, sessionId },
                    "Network.enable"
                );
            } catch (e) {}
        }
        try {
            await chrome.debugger.sendCommand(
                { tabId: source.tabId, sessionId },
                "Runtime.runIfWaitingForDebugger"
            );
        } catch (e) {}
        return;
    }

    if (method === "Network.responseReceived") {
        const { requestId, response } = params;
        const mimeType = response.mimeType.split(";")[0].trim();
        const contentLength = response.headers["Content-Length"] || response.headers["content-length"];

        // if (response.type === "Document") {
        //     detectWafHeaders(response.url, response.status, response.headers, currentVisitId);
        // }

        // const targetErrorCodes = [403, 404, 429, 500, 502, 503];
        // if (targetErrorCodes.includes(response.status)) {
        //     sendToServer("/log_event", {
        //         type: "BLOCK_DETECTED",
        //         visit_id: currentVisitId, // Step 3: Inject visit_id
        //         payload: {
        //             url: response.url,
        //             hits: [`HTTP_${response.status}`],
        //             domFlags: { datadome: false, perimeterx: false, incapsula: false },
        //             hidden: false,
        //             title: `HTTP ${response.status}`,
        //             timestamp: Date.now()
        //         }
        //     });
        // }

        if (shouldLogBody(mimeType, contentLength) && response.status >= 200 && response.status < 300) {
            requestMap.set(requestId, {
                url: response.url,
                status: response.status,
                mimeType: mimeType,
                sessionId: source.sessionId // NEW: store sessionId for OOPIFs
            });
        }
    }

    if (method === "Network.loadingFinished") {
        const { requestId } = params;
        const meta = requestMap.get(requestId);
        if (!meta) return;

        requestMap.delete(requestId);

        try {
            // NEW: pass sessionId through — Network.getResponseBody must be sent
            // to the same session that saw the response, or CDP returns
            // "No resource with given identifier" for OOPIF requests.
            const bodyResult = await chrome.debugger.sendCommand(
                { tabId: source.tabId, sessionId: meta.sessionId },
                "Network.getResponseBody",
                { requestId }
            );

            sendToServer("/log_network", {
                visit_id: currentVisitId, // Step 3: Inject visit_id
                url: meta.url,
                status: meta.status,
                mimeType: meta.mimeType,
                body: bodyResult.body,
                isBase64: bodyResult.base64Encoded,
                timestamp: Date.now()
            });
        } catch (e) {}
    }
});

// ============================================================================
// 4. Message Router (From Content Scripts)
// ============================================================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Step 3: Map sender tab ID to visit ID
    const tabId = sender.tab && sender.tab.id;
    if (!tabId) return;
    
    const currentVisitId = tabVisitMap.get(tabId);
    if (!currentVisitId) return;

    if (message.type === "DOM_BLOCK_DETECTED") {

        const scope = isTargetUrl(message.payload.url) ? "target" : "third_party";

        sendToServer("/log_event", {
            type: "BLOCK_DETECTED",
            visit_id: currentVisitId, // Step 3: Inject visit_id
            scope: scope, // NEW
            ...message.payload
        });
    } else if (message.type === "LOG_CRAWL_F9743") {
        sendToServer("/log_event", {
            type: "JS_API_CALL",
            visit_id: currentVisitId, // Step 3: Inject visit_id
            script_url: message.data.scriptURL,
            data: message.data.msg,
            timestamp: Date.now()
        });
    }
});

// ============================================================================
// 5. Native Header Interception (Race-Condition Free)
// ============================================================================

chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
        const currentVisitId = tabVisitMap.get(details.tabId);
        if (!currentVisitId) return;

        const isTarget = isTargetUrl(details.url); // no early return

        const headersMap = {};
        if (details.responseHeaders) {
            for (const header of details.responseHeaders) {
                headersMap[header.name.toLowerCase()] = header.value;
            }
        }

        detectWafHeaders(details.url, details.statusCode, headersMap, currentVisitId, isTarget);

        const targetErrorCodes = [403, 404, 429, 500, 502, 503];
        if (targetErrorCodes.includes(details.statusCode)) {
            sendToServer("/log_event", {
                type: "BLOCK_DETECTED",
                visit_id: currentVisitId,
                payload: {
                    url: details.url,
                    hits: [`HTTP_${details.statusCode}`],
                    domFlags: { datadome: false, perimeterx: false, incapsula: false },
                    hidden: false,
                    title: `HTTP ${details.statusCode}`,
                    scope: isTarget ? "target" : "third_party", // NEW
                    timestamp: Date.now()
                }
            });
        }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders"]
);

chrome.webRequest.onErrorOccurred.addListener(
    (details) => {
        const currentVisitId = tabVisitMap.get(details.tabId);
        if (!currentVisitId) return;

        const wafErrors = new Set([
            "net::ERR_CONNECTION_CLOSED",
            "net::ERR_CONNECTION_RESET",
            "net::ERR_CONNECTION_ABORTED",
            "net::ERR_EMPTY_RESPONSE",
            "net::ERR_HTTP2_PROTOCOL_ERROR",
            "net::ERR_SSL_PROTOCOL_ERROR"
        ]);
        if (!wafErrors.has(details.error)) return;

        sendToServer("/log_event", {
            type: "BLOCK_DETECTED",
            visit_id: currentVisitId,
            payload: {
                url: details.url,
                hits: [`NET_${details.error}`],
                domFlags: { datadome: false, perimeterx: false, incapsula: false },
                hidden: false,
                title: `Network Error: ${details.error}`,
                scope: isTargetUrl(details.url) ? "target" : "third_party", // NEW
                timestamp: Date.now()
            }
        });
    },
    { urls: ["<all_urls>"] }
);